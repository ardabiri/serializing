package filereadwrite;

public class Main {

	public static void main(String[] args) {
		FileReadWrite f= new FileReadWrite("C:/Users/alire/Desktop/testtext.txt");
		f.readFile();
		f.WriteFile("new text for test");

	}

}
