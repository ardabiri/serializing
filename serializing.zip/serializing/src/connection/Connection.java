package connection;

public class Connection {
	private String url;
	public static Connection c; 
	private Connection(String url) {
		this.url = url;
	}
	public static Connection getInstance(String url) {
		if (c == null) {
			c = new Connection(url);}			
		return c;			
	}
}
