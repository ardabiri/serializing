package serilize_deserialize;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User u = new User("mahsav","123v","543343v");
		u.serialized();
		u.deserialized();
	}

}
